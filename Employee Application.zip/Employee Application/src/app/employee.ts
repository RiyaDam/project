export class Employee{
        id : number=0;
        name: string='';
        address: string='';
        dob: Date | undefined;
        password: string='';
}