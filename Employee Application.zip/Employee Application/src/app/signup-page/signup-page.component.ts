import { analyzeAndValidateNgModules } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EmployeeService } from '../employee.service';
import { Employee } from '../employee';

@Component({
  selector: 'app-signup-page',
  templateUrl: './signup-page.component.html',
  styleUrls: ['./signup-page.component.css']
})
export class SignupPageComponent implements OnInit {
  invalidLogin:boolean = false;
  nextPage:boolean = false
  userName:string =''
  password:string = ''
  confirmPassword:string = ''
 
  employee:Employee=new Employee();
  message : any;
  constructor(private router: Router, private service: EmployeeService) { }

  ngOnInit() {
  }
  nextpage(){
    console.log("sample text")
    if(this.employee.id >= 1 &&  this.employee.address != ""){
      this.nextPage = !this.nextPage
      this.invalidLogin = false
      
    }
    else{
      this.invalidLogin = true
    }

  }
  backPage(){
    this.nextPage = !this.nextPage
  }
  public signUp(){
    if(this.employee.name != "" && this.employee.password !="" && this.employee.password == this.confirmPassword){
      
      this.invalidLogin = false
      let reponse = this.service.doSignupdata(this.employee);
      reponse.subscribe(data => {
        this.message = data;
      });
      alert("Hello "+this.employee.name+" , You have successfully Signed up!")
      this.router.navigate(['home']);
    }
    else{
      this.invalidLogin = true
    }
   
    
     

  }
  }



