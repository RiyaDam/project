import { Component, OnInit } from '@angular/core';
import { UrlSegment } from '@angular/router';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { AppComponent } from '../app.component';
import { EmployeeService } from '../employee.service';
import { Employee } from '../employee';
@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.css']
})
export class LoginPageComponent implements OnInit {
  employee=new Employee();
  invalidLogin:boolean = false;
  //userName:any =""
 // password:any = ""

  constructor(private router: Router,public appComp: AppComponent, public service: EmployeeService) { }

  ngOnInit(): void {
  }

  validate(typeOfLogin:any){
   // if(this.pacuser.userName!='' && this.pacuser.password!='')
    //{
      if(typeOfLogin=="user") {
this.service.loginPacuserFromRemote(this.employee).subscribe(
  data =>{
    console.log('response')
    this.invalidLogin = false
    this.service.setUserName(this.employee.name)
    this.service.setLoggedIn(true)
   
   this.router.navigate(['../userPage']);
 
        },
      
        error =>{console.log("exception")
        this.invalidLogin = true
      }
)
//else{
 // this.invalidLogin = true
//}
    }
    if(typeOfLogin=="admin")
  
    {
      if(this.employee.name=="Vishwa@admin" && this.employee.password=="tej") {
        this.service.setUserName(this.employee.name)
    this.service.setLoggedIn(true)
    this.invalidLogin = false
      this.router.navigate(['../adminPage']);
      }
      else{
        this.invalidLogin = true
      }
    }
          }
   openSignUp(){
    this.router.navigate(['../signup'])
          }
}
    

 