import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Employee } from './employee';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  private name: string = "";
  private loggedIn: boolean = false;
  
  constructor(private httpclient: HttpClient) { }
  getUserName() {
    return this.name;
  }
  setUserName(name: string) {
    this.name = name
  }
  getLoggedIn() {
    return this.loggedIn;
  }
  setLoggedIn(loggedIn: boolean) {
    this.loggedIn = loggedIn
  }
  
  public doSignupdata(employee:Employee){
    return this.httpclient.post("http://localhost:8081/employee", employee, {responseType : "text" as "json"});
  }

  public editUsersdata(employee:Employee){
    return this.httpclient.put("http://localhost:8081/employee/", employee, {responseType : "text" as "json"});
  }
  public getUserDatabyId(name:string){
    return this.httpclient.get("http://localhost:8081/employee/"+name);
  }

  
  public getSampleData() {
    return this.httpclient.get("http://localhost:8081/employee");
     }
   

  public deleteEmployee(id: string | number){
    return this.httpclient.delete("http://localhost:8081/employee/"+id);
  }

  public loginPacuserFromRemote(employee: Employee):Observable<any> {
    return this.httpclient.post<any>("http://localhost:8081/login", employee);
}
  
}
