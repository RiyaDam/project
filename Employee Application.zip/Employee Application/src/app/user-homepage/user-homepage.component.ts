import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Serializer } from 'v8';
import { EmployeeService } from '../employee.service';
import { Employee } from '../employee';

@Component({
  selector: 'app-user-homepage',
  templateUrl: './user-homepage.component.html',
  styleUrls: ['./user-homepage.component.css']
})
export class UserHomepageComponent implements OnInit {
  userTable:boolean = false;
  helpInfo:boolean = false
  help:boolean = false
  profile:boolean = false
  message : any;
  employee=new Employee();
  userData: any=[];
  //profile: boolean;
  //help: boolean;
  constructor(private router: Router,public service: EmployeeService) { }

  ngOnInit() {
    
  }

  onBtnClick(value:string){
    if(value == "profile"){
      this.userTable = false
      this.profile = true
      this.help = false
    }
    else if(value == "help"){
      this.userTable = false
      this.profile = false
      this.help = true
    }
    else if(value == "userTable"){
      this.userTable = true
      this.profile = false
      this.help = false
    }
    
  }
 
 public getUserDatabyId(){
  var uname=this.service.getUserName();
  let response1 = this.service.getUserDatabyId(uname);
  response1.subscribe(data => this.userData = data);
   
   alert("hello...  " +uname)
  
}

}
