import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EmployeeService } from '../employee.service';
import { TestObject } from 'protractor/built/driverProviders';
import { Employee } from '../employee';

@Component({
  selector: 'app-admin-homepage',
  templateUrl: './admin-homepage.component.html',
  styleUrls: ['./admin-homepage.component.css']
})
export class AdminHomepageComponent implements OnInit {
  invalidUser:boolean = false;
  userTable:boolean = false
  editusersPage:boolean = false
  editUser:boolean = false
  sampleData: any
  id: number=0
  name: string=''
  employee:Employee=new Employee();
  message: any;

  constructor(private router: Router,private service: EmployeeService) { }

  ngOnInit() {
    
  }
  

  public removeEmployee(id : number){
    let response = this.service.deleteEmployee(id);
    response.subscribe(data => this.sampleData = data);
    let response1 = this.service.getSampleData();
    response1.subscribe(data => this.sampleData = data);
  }

  

  onBtnClick(value:string){
    if(value == "user"){
      let response1 = this.service.getSampleData();
    response1.subscribe(data => this.sampleData = data);
      this.userTable = true
      this.editUser = false
    }
    
    else if(value == "editUser"){
      this.userTable = false
      this.editUser = true
    }
  }

 

public edituserspage(){
  if(this.employee.id >= 1 && this.employee.name != "" && this.employee.address != "" ){
   this.editusersPage = !this.editusersPage
   this.invalidUser = false
 }
  else{
   this.invalidUser = true
 }
 let reponse = this.service.editUsersdata(this.employee);
     reponse.subscribe(data => {
       this.message = data;
     });
}
  
}

