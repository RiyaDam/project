package com.employee.sample.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.employee.sample.model.employee;
import com.employee.sample.service.employeeService;

@RestController
@CrossOrigin({"http://localhost:4200","*"})
public class employeeController {
	@Autowired
	private employeeService es;
	
	@GetMapping("/")
	public String home()
	{
		return "Employee Data";
	}
	
	@GetMapping("/employee/{name}")
	public employee findpacUserById(@PathVariable String name)
	{
		employee empl=null;
		try
		{
			empl=es.read(name);
		}catch(EmptyResultDataAccessException erde)
		{
			empl=new employee();
		}
		return empl;
	}
	
	@PostMapping("/employee")
	public int addemployee(@RequestBody employee empl)
	{
		
		return es.create(empl);
	}
	
	@PostMapping("/login") 
	public employee loginUser(@RequestBody employee empl) throws Exception{
		String tempUserId=empl.getName();
		String tempPsw=empl.getPassword();
		employee emplObj=null;
		if(tempUserId !=null && tempPsw!=null)
		{
			emplObj=es.fetchUserByName(tempUserId, tempPsw);
		}
		if(emplObj==null) {
			throw new Exception("bad");
		}
		return emplObj;
	}
	
	@GetMapping("/employee")
	public List<employee> getAllemployees()
	{
		return es.read();
	}
	
	@PutMapping("/employee")
	public int modifyemployee(@RequestBody employee empl)
	{
		return es.update(empl);
	}
	
	@DeleteMapping("/employee/{id}")
	public int removeemployee(@PathVariable Long id)
	{
		return es.delete(id);
	}
}
