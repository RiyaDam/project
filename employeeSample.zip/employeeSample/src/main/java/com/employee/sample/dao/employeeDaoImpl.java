package com.employee.sample.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.employee.sample.model.employee;

@Component
public class employeeDaoImpl implements employeeDao{
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Override
	public int create(employee empl) {
		return jdbcTemplate.update("INSERT INTO EMPLOYEE VALUES (?,?,?,?,?)", empl.getId(), empl.getName(), empl.getAddress(), empl.getDob(), empl.getPassword());
	}
    
	@Override
	public List<employee> read() {
		return jdbcTemplate.query("SELECT * FROM EMPLOYEE", new employeeRowMapper());
	}
	
	@Override
	public employee read(String name) {
		return jdbcTemplate.queryForObject("SELECT * FROM EMPLOYEE WHERE name=?", new employeeRowMapper(), name);
	}
	
	@Override
	public employee fetchUserByName(String tempUserId, String tempPsw) {
		// TODO Auto-generated method stub
		return jdbcTemplate.queryForObject("SELECT * FROM EMPLOYEE WHERE name=? AND password=?", new employeeRowMapper(), tempUserId, tempPsw);
	}
	
	@Override
	public int update(employee empl) {
		return jdbcTemplate.update("UPDATE EMPLOYEE SET name=?, address=?, dob=?, password=? WHERE id=?",empl.getName(), empl.getAddress(), empl.getDob(), empl.getPassword() , empl.getId());
	}
	
	@Override
	public int delete(Long id) {
		return jdbcTemplate.update("DELETE FROM EMPLOYEE WHERE id=?",id);
	}

	@Override
	public List<employee> readbyId(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	
}
