package com.employee.sample.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.springframework.jdbc.core.RowMapper;

import com.employee.sample.model.employee;

public class employeeRowMapper implements RowMapper<employee>{
	@Override
	public employee mapRow(ResultSet rs, int rowNum) throws SQLException {
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		employee empl=null;
			try {
				empl= new employee(rs.getLong("id"), rs.getString("name"), rs.getString("address"), sdf.parse(rs.getString("dob")), rs.getString("password"));
			} catch (ParseException e) {
				empl=null;
			}
		return empl;
	}

}
